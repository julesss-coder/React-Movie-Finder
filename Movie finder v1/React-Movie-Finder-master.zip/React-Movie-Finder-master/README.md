## React Movie Finder, V 1 & 2

### Version 1
Based on the OMDb API (URL: http://www.omdbapi.com/) movie database.
Using HTML, Bootstrap 5, React.

Try it here: https://julesss-coder.github.io/React-Movie-Finder

### Version 2
Using Create React App.
Try it here: https://venerable-bombolone-570b5b.netlify.app/ 
